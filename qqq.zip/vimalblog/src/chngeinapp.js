import logo from './logo.svg'; import './App.css';
 import Header from './comp/Header'; 
 import {Routes, Route} from 'react-router-dom';

 <Routes>
    <Route path='/' element={<Display/>} exact /> 
    <Route path='/Disp/:id' element={<Display/>} exact /> 
    <Route path='*' element ={<Display/>} exact />
 </Routes>

