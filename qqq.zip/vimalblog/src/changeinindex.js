import {BrowserRouter} from 'react-router-dom';
<BrowserRouter> <App /> </BrowserRouter>